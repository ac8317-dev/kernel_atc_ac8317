/*
 *
 *  AC83XX architecture timex specifications
 *
 *  Copyright (C) 2009 MediaTek Inc.
 *
 */

#ifndef TIMEX_H_
#define TIMEX_H_

#define CLOCK_TICK_RATE		(27000000 / 16)

#endif /* TIMEX_H_ */
