/*
 *  kernel/arch/arm/mach-ac83xx/include/mach/dma.h
 *
 *  Copyright (C) 2009 MediaTek Inc.
 *
 */
#ifndef __ASM_ARCH_DMA_H
#define __ASM_ARCH_DMA_H
/*
#define MAX_DMA_ADDRESS		0xffffffff
#define MAX_DMA_CHANNELS	0
*/
#endif /* _ASM_ARCH_DMA_H */

