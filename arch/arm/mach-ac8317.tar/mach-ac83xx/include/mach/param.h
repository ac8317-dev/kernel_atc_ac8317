/*
 *  linux/arch/arm/mach-ac83xx/include/mach/param.h
 *
 *  Copyright (C) 2009 MediaTek Inc.
 *
 */

#define HZ 100
