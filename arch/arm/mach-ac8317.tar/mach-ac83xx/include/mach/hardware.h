/*
 *  linux/include/asm-arm/arch-ac83xx/hardware.h
 *
 *  Copyright (C) 2009 MediaTek Inc.
 *
 */
#ifndef __ASM_ARCH_HARDWARE_H
#define __ASM_ARCH_HARDWARE_H

#include <asm/mach-types.h>

#include <mach/ac83xx.h>

//#include <mach/ac83xx_basic.h>

#endif

